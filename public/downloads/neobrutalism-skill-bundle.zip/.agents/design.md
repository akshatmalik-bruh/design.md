# design.md: Neobrutalism (v0.1)

Read `structure.md` and `components.md` alongside this file.
This file defines how things LOOK and MOVE. Use it for every UI you build in this project.

Reference: neobrutalism.dev (MIT). Values below come from its published Blue palette and Button source.
Items tagged **[recommended]** are additions by this skill, not copied from the reference.
Items tagged **[verify]** were not checked against the live site; confirm before relying on them.

---

## 1. The look in one sentence

Flat, saturated color blocks with 2px black outlines and hard 4px offset shadows, black text everywhere (including on the accent), and a physical press-into-the-page motion.

## 2. Tokens

Put these in `app/globals.css` (Tailwind v4). Never hard-code the values inside components.

```css
:root {
  --background: hsl(214 95% 93%);
  --secondary-background: oklch(100% 0 0);
  --main: hsl(217 100% 66%);
  --foreground: oklch(0% 0 0);
  --main-foreground: oklch(0% 0 0);
  --border: oklch(0% 0 0);
  --ring: oklch(0% 0 0);
  --overlay: oklch(0% 0 0 / 0.8);
  --shadow: 4px 4px 0px 0px var(--border);

  --chart-1: #5294ff;
  --chart-2: #ff4d50;
  --chart-3: #facc00;
  --chart-4: #05e17a;
  --chart-5: #7a83ff;
}

@theme inline {
  --color-background: var(--background);
  --color-secondary-background: var(--secondary-background);
  --color-main: var(--main);
  --color-foreground: var(--foreground);
  --color-main-foreground: var(--main-foreground);
  --color-border: var(--border);
  --color-ring: var(--ring);
  --color-overlay: var(--overlay);

  --spacing-boxShadowX: 4px;
  --spacing-boxShadowY: 4px;
  --spacing-reverseBoxShadowX: -4px;
  --spacing-reverseBoxShadowY: -4px;

  --radius-base: 5px;
  --font-weight-base: 500;
  --font-weight-heading: 700;
  --shadow-shadow: var(--shadow);
}

@layer base {
  body { font-weight: var(--font-weight-base); color: var(--foreground); }
  h1, h2, h3, h4, h5, h6 { font-weight: var(--font-weight-heading); }
}
```

Token names must match exactly. They generate the utility classes used everywhere:
`bg-main`, `bg-background`, `bg-secondary-background`, `text-main-foreground`, `border-border`,
`shadow-shadow`, `rounded-base`, `font-base`, `font-heading`,
`translate-x-boxShadowX`, `translate-y-boxShadowY`, `translate-x-reverseBoxShadowX`, `translate-y-reverseBoxShadowY`.

| Token | Role |
|---|---|
| `background` | page background |
| `secondary-background` | white surfaces: cards, inputs, neutral controls |
| `main` | accent surface (primary actions, selected states) |
| `foreground` | normal text |
| `main-foreground` | text/icons placed ON `main` (black) |
| `border` | every outline |
| `ring` | keyboard focus ring |
| `overlay` | modal backdrop |

Palettes are swappable. Only these may change per palette: `background`, `main`, `secondary-background`, `chart-1..5`. Keep geometry tokens fixed.

## 3. Geometry rules

- Border: 2px solid `border` on every interactive or card-like surface.
- Radius: `rounded-base` (5px). No pills, no large radii.
- Shadow: `shadow-shadow` = `4px 4px 0 0` black. Zero blur, zero spread.
- Fills: flat color only (`main`, `secondary-background`, `background`).
- Text on `main` is BLACK (`text-main-foreground`). Never switch it to white.
- Body weight 500, headings 700. Do not force a font family; use `next/font` to load one the project chooses.
- Scrollbar is deliberately visible: 16px wide, black thumb, white track. Do not hide it.
- Light mode only. Do not add dark mode unless the user explicitly asks to depart from the system.

## 4. The core interaction rule

**Move the element by exactly its shadow offset, then remove the shadow.**

```
Normal (default, neutral)
  rest : shadow 4px 4px, no transform
  hover: translate(4px, 4px), shadow none        -> "pressed into the page"

Reverse
  rest : no shadow, no transform
  hover: translate(-4px, -4px), shadow 4px 4px    -> "lifted off the page"

noShadow
  flat, no movement
```

Tailwind form (normal): `shadow-shadow hover:translate-x-boxShadowX hover:translate-y-boxShadowY hover:shadow-none`
Tailwind form (reverse): `hover:translate-x-reverseBoxShadowX hover:translate-y-reverseBoxShadowY hover:shadow-shadow`

Use the offset tokens, never arbitrary values like `translate-y-1` or `shadow-[4px_4px_0_black]`.
Use `transition-all` (same as the reference Button).

## 5. States

- **Focus (keyboard):** `focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-black focus-visible:ring-offset-2`. Always visible.
- **Disabled:** `disabled:pointer-events-none disabled:opacity-50` and `data-disabled:pointer-events-none data-disabled:opacity-50` (Base UI components).
- **Active (pressed) [recommended]:** the reference defines no separate pressed state. On touch screens hover never fires, so add `active:translate-x-boxShadowX active:translate-y-boxShadowY active:shadow-none` to normal-shadow controls so taps feel the same as hover.

## 6. Motion [recommended]

The reference only specifies the hover/press shift. Add these, and nothing more:

- Use CSS transitions only. No animation library required.
- Duration 100 to 150ms, ease-out for press/lift. Keep it snappy; never exceed 200ms for control feedback.
- One page-load moment at most (for example the hero block sliding in once). Do NOT fade-and-slide every section, and do NOT add hover animations to every card.
- Wrap hover-only effects so they don't stick on touch devices: `@media (hover: hover)`.
- Always respect reduced motion: in `globals.css`
  ```css
  @media (prefers-reduced-motion: reduce) {
    *, *::before, *::after { transition-duration: 0.01ms !important; animation-duration: 0.01ms !important; }
  }
  ```
- Decorative loops (such as the marquee in the reference: `marquee 5s linear infinite`) must pause or stop under reduced motion.

## 7. Responsive rules [recommended]

- Mobile first. Build for 375px, then enhance at Tailwind `sm` (640), `md` (768), `lg` (1024), `xl` (1280).
- Shadows stay 4px at every size. Do not shrink them on mobile; they are the style.
- Tap targets at least 40px high (default button `h-10` already meets this).
- Use fluid heading sizes with `clamp()` or responsive classes (`text-3xl md:text-5xl lg:text-6xl`).
- Layout: single column below `md`; grids go 1 -> 2 -> 3 columns. Cards keep the same border and shadow when stacked, with at least 24px gap so shadows never touch the next card.
- Navbar collapses to a menu button below `md` (see components.md).
- Wide content (tables, code) scrolls inside its own `overflow-x-auto` container; the page never scrolls sideways.
- Test at 375, 768 and 1280px before finishing.

## 8. Anti-patterns

Do not use: blurred or soft shadows, gradients, glassmorphism, large corner radii, white text on `main`, thin gray borders, low-contrast controls, scale-on-hover as the default effect, dark mode, hidden scrollbars, `bg-blue-400` or `border-black` inside reusable components (use tokens).
Avoid making components look like generic shadcn with only a blue color: the black 2px border, hard shadow and press movement are what define the style.

## 9. Order of application

1. Semantic tokens. 2. 2px border. 3. 5px radius. 4. Hard shadow. 5. Black text on `main`. 6. Press/lift movement. 7. Type weights. 8. Component spacing. 9. Focus and disabled. 10. Responsive layout.
Add decoration last, and only if it serves the content.
