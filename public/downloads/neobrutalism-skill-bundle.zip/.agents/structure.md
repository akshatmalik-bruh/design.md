# structure.md: Code organization (v0.1)

Read `design.md` and `components.md` alongside this file.
Target stack: **Next.js (App Router) + React + TypeScript + Tailwind CSS v4**.
Build every page as a small system of reusable parts, not one long block of markup.
This file does not require a component library. Use native HTML first; add an accessible primitive library only where noted.

---

## 1. Folder layout

```
app/
  layout.tsx            # next/font, <html>, <body>, theme attribute
  page.tsx              # assembles sections only
  globals.css           # tokens, base layer, reduced-motion (see design.md)
components/
  ui/                   # primitives: button, input, card, badge, field, tabs...
  sections/             # navbar, hero, features, pricing, faq, footer
  layout/               # container, section
data/
  site.ts               # all copy, links, plans, features, FAQs
lib/
  utils.ts              # cn()
```

## 2. Layers (a layer may only use layers below it)

1. **Tokens**: CSS variables in `globals.css`.
2. **Base layer**: low-specificity element defaults in `@layer base` (headings, paragraphs, links, `:focus-visible`). This is the "classless baseline": plain `<h1>`, `<p>`, `<button>` already look right.
3. **Primitives** (`components/ui`): no page-specific copy.
4. **Layout** (`components/layout`): `Container`, `Section`, and optionally `Stack`, `Inline`, `Grid`. Keep this vocabulary small.
5. **Sections** (`components/sections`): compose primitives; receive content through props.
6. **Page**: imports sections and data, nothing else.

## 3. Rules

1. **Tokens only.** No hex values, no `bg-gray-100` or `border-neutral-200`, no `shadow-[...]` inside components. Use `bg-surface-2`, `border-line`, `shadow-float`.
2. **4px grid.** Integer spacing utilities only (`p-4`, `gap-6`). No `p-2.5`, `gap-1.5`, or arbitrary values like `mt-[13px]`.
3. **Define once, use many times.** A structure that appears twice becomes a component. Repeated items render from arrays (three plans = one `PricingCard` mapped over `plans`).
4. **Content lives in `data/`.** Headlines, labels, links and lists are typed objects. Changing text never means editing JSX structure.
5. **Variants, not copies.** `cva` with `variant` and `size` props. Never `Button2` or `PrimaryButtonLarge`.
6. **Shared layout primitives for all spacing and widths.** No one-off margins to fix a gap.
7. **One component per file**, kebab-case file names under `ui/`, named exports.
8. **Props pass-through.** Accept `className` and `...props`, merge with `cn()`.
9. **Flat class lists.** No `!important` (the reduced-motion rule is the one exception). Keep the base layer low-specificity so utility classes always win.
10. **Consistent naming.** One convention throughout. Variant names: `default`, `secondary`, `inverted`, `ghost`, `destructive`; sizes: `sm`, `default`, `lg`, `icon`, `icon-sm`.
11. **State through ARIA and native attributes**, not custom ones: `aria-selected`, `aria-expanded`, `aria-current`, `aria-invalid`, `disabled`, `open`. Do not invent a custom state attribute when HTML already expresses the state.

## 4. Should this be a component? (ask before creating one)

1. Can native HTML solve it (`details`, `dialog`, `select`, `table`)?
2. Can an existing primitive solve it?
3. Does the pattern repeat?
4. Does the abstraction reduce complexity?

If the answers are mostly no, write plain markup. Do not add components to increase their number.

## 5. `cn()`

```ts
// lib/utils.ts
import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
export function cn(...inputs: ClassValue[]) { return twMerge(clsx(inputs)) }
```

## 6. Base layer example

```css
@layer base {
  body { background: var(--bg); color: var(--fg1); font-size: 1rem; line-height: 1.5rem; }
  h1, h2, h3 { font-weight: 500; }
  p { max-width: 65ch; }
  a { text-underline-offset: 4px; }
  :focus-visible { outline: 2px solid var(--focus); outline-offset: 2px; }
}
```

## 7. Server and client components

- Default to **server components**. Hover, focus and press effects are CSS, so they need no client code.
- Add `'use client'` only where state or event handlers are required: mobile menu toggle, dialog (`showModal()`), tabs, forms with validation, toasts. Keep those components small and at the leaf.
- Do not render values that differ between server and client (dates, random IDs) without handling hydration.

## 8. Next.js specifics

- Fonts via `next/font` in `app/layout.tsx`, exposed as a CSS variable. Never a `<link>` tag.
- Images via `next/image` with explicit dimensions.
- Links via `next/link`. A link that looks like a button uses `buttonVariants()`.
- Export `metadata` (title, description) from `layout.tsx` or `page.tsx`.
- Theme: if dark mode is wanted, set `data-theme` on `<html>` and swap tokens only (see design.md). Do not add per-component dark classes.

## 9. Accessible primitives

Use native elements wherever they meet the need. For complex behavior (combobox, menu with typeahead, date picker, focus-managed overlays), use an established accessible primitive library (for example Base UI, Radix or React Aria) instead of rebuilding keyboard behavior. Check which one the project already uses and follow its composition API. Style its state through the attributes it exposes and through ARIA. Do not add a second primitive library to a project that already has one.

## 10. Workflow

1. List the sections the page needs and which items repeat.
2. Confirm tokens in `globals.css` (design.md).
3. Create `data/site.ts` with all copy.
4. Build primitives, then layout primitives, then sections.
5. Assemble `app/page.tsx` from sections and data.
6. Test at 375, 768 and 1280px; tab through with the keyboard.
7. Run the "remove before adding" pass: delete any element that does not improve hierarchy, usability, state or accessibility.

## 11. Before you say you're done

- Any JSX block repeated more than once? Extract a component and map over data.
- Any hex value, default-palette color, fractional spacing or arbitrary pixel value outside the token layer?
- Can the headline, a card's text and the whole palette each be changed in one place?
- Is there any shadow on a flat surface, any gradient, any scale-on-hover, any radius above `rounded-lg` (outside circles)?
- Only the durations 120, 180 and 280ms, and one easing curve?
- Every icon-only control has `aria-label`; every input has a label; focus is visible everywhere?
- Reduced-motion rule present? No horizontal scroll at 375px?