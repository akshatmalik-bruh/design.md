# components.md: Building components (v0.1)

Read `design.md` and `structure.md` alongside this file.
This file says HOW to build each component. `design.md` says how it looks.
Use token classes only (`bg-main`, `border-border`, `shadow-shadow`, `rounded-base`). Never literal colors or pixel shadows.

Tags: **[source]** = taken from neobrutalism.dev's published Button code. **[verify]** = from secondary notes, check against the site. **[recommended]** = written by this skill for landing pages.

---

## Ground rules for every component

1. Semantic HTML first: real `<button>`, `<a>`, `<nav>`, `<header>`, `<section>`, `<label>`.
2. Variants through `cva` (class-variance-authority) and a `variant` prop. Never copy a component to make a variant.
3. Merge classes with `cn()` so callers can override.
4. Every interactive element: visible focus ring, disabled state, accessible name (`aria-label` on icon-only controls).
5. Pass `className` and `...props` through.
6. Add `data-slot="name"` on the root element.

---

## 1. Button [source]

Base classes:

```
inline-flex items-center justify-center whitespace-nowrap rounded-base text-sm font-base
ring-offset-white transition-all gap-2
[&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0
focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-black focus-visible:ring-offset-2
disabled:pointer-events-none disabled:opacity-50
data-disabled:pointer-events-none data-disabled:opacity-50
```

| Variant | Classes | Behavior |
|---|---|---|
| `default` | `text-main-foreground bg-main border-2 border-border shadow-shadow hover:translate-x-boxShadowX hover:translate-y-boxShadowY hover:shadow-none` | pressed on hover |
| `neutral` | `bg-secondary-background text-foreground border-2 border-border shadow-shadow hover:translate-x-boxShadowX hover:translate-y-boxShadowY hover:shadow-none` | white, pressed on hover |
| `noShadow` | `text-main-foreground bg-main border-2 border-border` | flat |
| `reverse` | `text-main-foreground bg-main border-2 border-border hover:translate-x-reverseBoxShadowX hover:translate-y-reverseBoxShadowY hover:shadow-shadow` | lifts on hover |

| Size | Classes |
|---|---|
| `default` | `h-10 px-4 py-2` |
| `xs` | `h-8 gap-1.5 px-2.5 text-xs [&_svg]:size-3.5` |
| `sm` | `h-9 px-3` |
| `lg` | `h-11 px-8` |
| `icon` | `size-10` |
| `icon-xs` | `size-8 [&_svg]:size-3.5` |
| `icon-sm` | `size-9` |
| `icon-lg` | `size-11` |

Defaults: `variant="default"`, `size="default"`.
Add touch feedback [recommended]: `active:translate-x-boxShadowX active:translate-y-boxShadowY active:shadow-none` on `default` and `neutral`.

### Button as a link (important)

The Base UI button always sets `role="button"`. Do NOT do `<Button render={<a />}>`.
Use the variants helper on a Next.js link:

```tsx
import Link from "next/link"
import { buttonVariants } from "@/components/ui/button"

<Link href="/pricing" className={buttonVariants({ variant: "default" })}>See pricing</Link>
```

Export `buttonVariants` from `button.tsx` for this reason.

### Button copy
Say what happens: "Start free trial", "Save changes", never "Submit" or "Click here".

---

## 2. Card [verify]

Recipe: `bg-secondary-background text-foreground border-2 border-border rounded-base shadow-shadow`.
(`bg-main text-main-foreground` for a highlighted card.)
Parts: `Card`, `CardHeader`, `CardTitle` (heading weight), `CardDescription`, `CardContent`, `CardFooter`.
Spacing reference: header `p-6`, content `p-6 pt-0`, footer `flex items-center p-6 pt-0`.
Cards are static: no hover movement unless the whole card is a link. If it is a link, apply the Button press behavior to the card.
Gap between cards at least `gap-6` so shadows do not touch neighbors.

## 3. Input and Textarea [verify]

`bg-secondary-background text-foreground border-2 border-border rounded-base` plus the focus ring from design.md.
Height `h-10` for inputs; `px-3`. Placeholder uses reduced-opacity foreground, still readable.
Always pair with a visible `<label>`. Errors: text message under the field plus `aria-invalid`, never color alone.

## 4. Badge [verify]

`inline-flex items-center rounded-base border-2 border-border px-2.5 py-0.5 text-xs font-base`.
Variants: `default` (`bg-main text-main-foreground`), `neutral` (`bg-secondary-background text-foreground`).
Never a pill shape.

## 5. Navigation link (inside navbar) [verify]

`rounded-base border-2 border-transparent px-3 py-2 hover:bg-main hover:text-main-foreground hover:border-border`.
Active page: `bg-main border-border`. Use `next/link`.

---

## 6. Marketing navbar [recommended]

Structure: `<header>` with `border-b-2 border-border bg-secondary-background`, containing a `<nav aria-label="Main">`.

- Left: logo/brand as a link to `/`.
- Center/right (from `md` up): 3 to 5 nav links, then ONE primary `Button` (the page's main call to action).
- Below `md`: show only the logo and a menu icon button (`size="icon"`, `aria-label="Open menu"`, `aria-expanded`). The menu opens as a Sheet or a full-width panel with stacked links and the call-to-action at the bottom.
- Sticky is fine: `sticky top-0 z-50`. Keep height around `h-16`.
- The menu toggle needs `'use client'`; keep the rest of the navbar a server component.

## 7. Hero [recommended]

Layout: one `<section>` with generous vertical padding (`py-16 md:py-24`), content constrained by the container primitive.

- One `<h1>` (heading weight, large, tight leading). State the benefit, not the product category.
- One supporting paragraph, max about 60 characters per line is not required but keep it under 2 sentences.
- Exactly one primary button and at most one secondary (`neutral`) button.
- Visual: a card-style block (2px border + hard shadow) holding an image, screenshot or illustration. No gradients or blurred shapes.
- Social proof strip below (logos or numbers) is optional.
- Mobile: single column, button full width if two buttons stack.

## 8. Section wrapper [recommended]

A `Section` component with consistent vertical padding and optional `bg-background` or `bg-main` bands. Use `border-y-2 border-border` to separate colored bands. All sections use the same horizontal container.

## 9. Pricing card [recommended]

Card with plan name, price (large), 3 to 6 feature lines, one button. The recommended plan uses `bg-main` and a `Badge`. Render all plans from a data array via one `PricingCard` component.

## 10. FAQ [recommended]

Accordion of stacked bordered panels: trigger `bg-main text-main-foreground font-heading`, content `bg-secondary-background`. Use the Base UI accordion state attributes (`data-panel-open`) for open styling.

## 11. Footer [recommended]

`border-t-2 border-border bg-secondary-background`. Link columns, one line of legal text. No call-to-action competing with the hero's.

## 12. Dialog, Sheet, Popover, Dropdown (overlays) [verify]

Solid `bg-secondary-background`, `border-2 border-border`, `rounded-base`, `shadow-shadow`. Backdrop is `bg-overlay`. Keep corners compact.
Base UI rules: compose triggers with `render`, e.g. `<DialogTrigger render={<Button />}>Open</DialogTrigger>`. Popups take `side`, `sideOffset`, `align`, `alignOffset` directly.
`DialogContent` and `SheetContent` accept `showCloseButton`.

## 13. Tabs, Toggle, Pagination [verify]

Treat as compact button-style controls: 2px border, 5px radius. Active/selected = `bg-main text-main-foreground`; inactive = `bg-secondary-background`. Style state with Base UI attributes (`data-active`, `data-pressed`, `data-checked`), not `data-state`.

## 14. Generic recipe for anything not listed

```
surface : bg-secondary-background text-foreground border-2 border-border rounded-base
primary : bg-main text-main-foreground
raised  : shadow-shadow
press   : hover:translate-x-boxShadowX hover:translate-y-boxShadowY hover:shadow-none
focus   : focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-black focus-visible:ring-offset-2
disabled: disabled:pointer-events-none disabled:opacity-50
```

## Components to verify before documenting further

Field, Input Group, Item, Kbd, Marker, Message, Message Scroller, Questionnaire, Toast, Attachment, Bubble, Button Group, Native Select, Spinner. Their names and props were not checked against the live docs. Read each component's page on neobrutalism.dev, or install it with the shadcn CLI, before writing rules for it.