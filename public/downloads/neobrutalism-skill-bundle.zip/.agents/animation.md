# NEOBRUTALISM_MOTION_SKILL.md

## Purpose

Define the motion language for neobrutalist / brutalist landing pages.

This is not a generic GSAP library.

The goal is to make the interface feel:
- physical
- bold
- graphic
- spatial
- playful
- slightly unpredictable
- tactile
- high-energy

Motion should amplify strong borders, hard shadows, oversized type, panels, cards and geometric layouts.

---

# 1. Core Motion Personality

Neobrutalism benefits from **physical movement**.

Think:

```text
panels
cards
layers
objects
blocks
stacks
collisions
directional movement
```

Preferred characteristics:
- sticky sections
- pinned storytelling
- horizontal scrolling
- parallax
- overlapping panels
- cards stacking over each other
- hard directional reveals
- image movement
- large geometric transitions
- controlled rotation
- snap points
- strong entrance/exit motion

Unlike minimalism, the animation can be visibly obvious.

But it should still be intentional.

---

# 2. Default Motion Tokens

```css
--motion-fast: 180ms;
--motion-normal: 400ms;
--motion-slow: 700ms;

--motion-distance-sm: 32px;
--motion-distance-md: 80px;
--motion-distance-lg: 160px;

--motion-rotate-sm: 2deg;
--motion-rotate-md: 5deg;
```

Preferred easing:

```js
ease: "power3.out"
ease: "power4.out"
ease: "power2.inOut"
ease: "none" // scroll-linked movement
```

For scrub:

```js
scrub: 0.5
scrub: 1
```

---

# 3. Smooth Scroll

Smooth scrolling is still recommended.

But the smoothness should not make brutalism soft.

Use smooth scroll as the base layer, then create strong movement on top.

The combination should feel:

```text
smooth scroll
+
hard geometry
+
physical movement
```

---

# 4. Signature Effect: Pinned Storytelling

This should be one of the primary neobrutalist effects.

Pattern:

```text
┌───────────────────────────┐
│                           │
│      FIXED VISUAL         │
│                           │
│   content changes here    │
│                           │
└───────────────────────────┘
```

The section pins while internal elements animate.

Example:

```js
gsap.timeline({
  scrollTrigger: {
    trigger: section,
    pin: true,
    scrub: 1,
    start: "top top",
    end: "+=2000"
  }
});
```

Use this for:
- product walkthroughs
- feature storytelling
- process sections
- large visual narratives

Important:

Do not animate the pinned element itself if that affects ScrollTrigger measurements. Animate children inside the pinned container.

---

# 5. Overlapping Sections

A strong brutalist pattern:

```text
SECTION A
████████████████

        ↓ scroll

SECTION B
    ████████████████
    overlaps A
```

The second section should visually intrude into the previous section.

Techniques:
- negative margins
- sticky containers
- z-index layering
- translateY
- clip-path
- GSAP-controlled overlap

This is excellent for:
- testimonials
- feature blocks
- project cards
- CTA sections

---

# 6. One Section Coming Over Another

Use this as a signature transition.

Concept:

```text
Hero
████████████████

scroll ↓

Features
      ███████████████
      ███████████████
      ███████████████
```

Animation:

```text
yPercent: 100 → 0
```

Optional:

```text
scale: 0.96 → 1
```

Optional:

```text
rotate: -1deg → 0
```

The result should feel like a physical sheet/card sliding over another sheet.

---

# 7. Horizontal Scroll Controlled by Vertical Scroll

One of the strongest brutalist patterns.

User scrolls vertically.

The page pins.

Content moves horizontally:

```text
[01] → [02] → [03] → [04]
```

Typical structure:

```js
gsap.to(panels, {
  xPercent: -100 * (panels.length - 1),
  ease: "none",
  scrollTrigger: {
    trigger: container,
    pin: true,
    scrub: 1,
    snap: 1 / (panels.length - 1)
  }
});
```

Use for:
- product features
- portfolio projects
- timeline
- case studies
- visual galleries

---

# 8. Horizontal Scroll + Parallax

Do not only move the panels.

Move the contents at different speeds.

Example:

```text
panel → moves left quickly
image → moves left slowly
text → moves slightly
decorative shape → moves differently
```

This creates depth.

GSAP's `containerAnimation` is useful for triggering animations inside a horizontally animated container.

Important:
- horizontal container animation should use `ease: "none"`
- inner triggers using `containerAnimation` have limitations around pinning/snapping

---

# 9. Image Parallax

Brutalism can use stronger parallax than minimalism.

Recommended:

```text
container movement: 100px
image movement: 30–80px
```

Possible directions:
- vertical
- horizontal
- diagonal

Image can also slightly scale:

```text
scale: 1.08 → 1
```

The image should remain clipped by an overflow-hidden parent.

---

# 10. Sticky Cards / Card Stack

Cards stack as the user scrolls.

Example:

```text
CARD 01
████████████

CARD 02
  ████████████

CARD 03
    ████████████
```

Each card:
- becomes sticky
- overlaps previous cards
- optionally scales down
- optionally rotates slightly

Suggested behavior:

```text
card 1 → scale 1.00
card 2 → scale 0.97
card 3 → scale 0.94
```

Keep the scale difference small.

The physical stacking is more important than the scale.

---

# 11. Hard Directional Reveals

Use strong movement.

Examples:

```text
left → right
right → left
bottom → top
top → bottom
```

Unlike minimalist motion, distances can be larger.

Example:

```js
xPercent: -100 → 0
```

or:

```js
yPercent: 100 → 0
```

Best for:
- panels
- cards
- large images
- section transitions

---

# 12. Split-Screen Reveal

A brutalist transition can divide the viewport:

```text
████████ | ░░░░░░░░
████████ | ░░░░░░░░
████████ | ░░░░░░░░
```

Then the two sides move apart.

Possible sequence:

```text
left panel → xPercent: -100
right panel → xPercent: 100
content → opacity: 0 → 1
```

Excellent for:
- hero entrances
- project transitions
- page transitions

---

# 13. Oversized Typography Motion

Brutalist typography can move dramatically.

Use:
- horizontal drift
- vertical displacement
- slight rotation
- scale
- clipping
- text entering from outside viewport

Example:

```text
BUILD
       BUILD
             BUILD
```

Use huge text as a visual object.

Do not animate every word independently unless the effect specifically requires it.

---

# 14. Scroll-Scrubbed Rotation

Brutalism can tolerate small rotations.

Example:

```js
gsap.to(card, {
  rotation: 4,
  scrollTrigger: {
    trigger: card,
    scrub: true
  }
});
```

Recommended range:

```text
±1° → ±5°
```

Use for:
- cards
- labels
- stickers
- decorative blocks

Avoid turning the entire page into a spinning interface.

---

# 15. Layered Parallax

Use multiple layers:

```text
BACKGROUND      speed 0.05
SHAPE           speed 0.15
IMAGE           speed 0.25
TEXT            speed 0.10
FOREGROUND      speed 0.30
```

This creates depth without requiring WebGL.

Ideal for:
- hero sections
- product mockups
- editorial illustrations
- portfolio sections

---

# 16. Scroll-Scrubbed Color Changes

Brutalism can use stronger color state transitions than minimalism.

Example:

```text
white
  ↓
yellow
  ↓
black
  ↓
blue
```

Use `ScrollTrigger` progress to interpolate:
- background
- border
- text
- accent
- shadow

Color changes should correspond to section transitions, not happen constantly.

---

# 17. Sticky + Horizontal + Parallax Composite

This should be considered an advanced signature effect.

Sequence:

```text
vertical scroll
      ↓
section pins
      ↓
content moves horizontally
      ↓
images parallax
      ↓
cards enter
      ↓
text changes
      ↓
section unpins
```

This is excellent for a premium neobrutalist case study.

---

# 18. Snap Scrolling

Use snap selectively.

Good for:

```text
[01] [02] [03] [04]
```

where each panel is a deliberate composition.

Avoid snapping ordinary page sections because it can make navigation feel forced.

---

# 19. Hero Choreography

A strong brutalist hero:

1. navigation enters from side
2. giant heading slides in
3. decorative block enters
4. CTA snaps into position
5. hero image shifts with parallax
6. scroll indicator moves
7. next section starts covering hero

Example:

```text
NAV        → x: -40
HEADING    → x: -100
CARD       → y: 100
IMAGE      → scale: 1.08 → 1
DECOR      → rotate: -4 → 0
NEXT       → yPercent: 100 → 0
```

---

# 20. Signature Effect Priority

Build these first:

1. PinnedStory
2. OverlappingPanels
3. HorizontalScroll
4. HorizontalParallax
5. StickyCards
6. ImageParallax
7. DirectionalReveal
8. LayeredParallax
9. SplitReveal
10. ScrollColorTransition
11. OversizedTextMotion
12. SnapPanels

These should become the core neobrutalist animation toolkit.

---

# 21. Effects To Avoid By Default

Avoid:
- soft floating animations everywhere
- excessive blur
- tiny opacity changes
- delicate micro-movement
- generic fade-up on every element
- excessive 3D
- continuous rotation
- scroll-jacking
- animation without structural purpose

Neobrutalism should feel physical rather than ethereal.

---

# 22. Responsive Rules

Desktop can use:
- pinned sections
- horizontal scroll
- layered parallax
- sticky cards
- overlapping panels

Mobile should simplify aggressively.

Prefer:
- vertical storytelling
- reduced parallax
- fewer pinned sections
- no forced horizontal interaction
- shorter scroll distances
- fewer simultaneous animations

If horizontal storytelling is retained, keep each panel simple and ensure touch interaction remains natural.

Use `gsap.matchMedia()` for desktop/mobile variants.

---

# 23. React / GSAP Rules

Use scoped GSAP contexts:

```js
const ctx = gsap.context(() => {
  // animations
}, container);

return () => ctx.revert();
```

Use `gsap.matchMedia()` for responsive setups.

Always clean up:
- ScrollTriggers
- timelines
- event listeners
- observers

Avoid global animations that survive component unmount.

---

# 24. Pinning Rules

When using:

```js
pin: true
```

prefer:

```text
pinned container
    ├── animated text
    ├── animated image
    ├── cards
    └── decorative elements
```

rather than animating the pinned container itself.

This keeps ScrollTrigger's measurements stable.

---

# 25. Neobrutalist Landing Page Recipe

### Hero
`OversizedTextMotion + ImageParallax + DirectionalReveal`

### Intro
`OverlappingPanels`

### Features
`PinnedStory`

### Product showcase
`HorizontalScroll + HorizontalParallax`

### Testimonials
`StickyCards`

### Case study
`PinnedStory + LayeredParallax`

### Final CTA
`PanelReveal + ScrollColorTransition`

---

# 26. Motion Density

Recommended density:

```text
Hero              HIGH
Feature story     MEDIUM-HIGH
Gallery           HIGH
Cards             MEDIUM
Typography        MEDIUM-HIGH
Navigation        LOW
Footer            LOW
```

Not every element needs movement.

The page should have moments of stillness so the strong effects have impact.

---

# 27. Design Test

The animation is correct when:

- the interface feels physical
- panels feel like objects
- scrolling reveals structure
- horizontal movement feels intentional
- depth is obvious
- typography has visual weight
- transitions feel like composition changes
- the animation supports the brutalist geometry

Final principle:

> Neobrutalism should feel like the page has physical layers that the user is moving through.
