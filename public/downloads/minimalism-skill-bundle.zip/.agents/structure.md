# structure.md: Code organization (v0.1)

Read `design.md` and `components.md` alongside this file.
Target stack: **Next.js (App Router) + React + TypeScript + Tailwind CSS v4**, shadcn-style components on **Base UI**.
Build every page as a small system of reusable parts, not one long block of markup.

---

## 1. Folder layout

```
app/
  layout.tsx            # fonts (next/font), <body className="relative isolate">
  page.tsx              # assembles sections only
  globals.css           # tokens + base styles (see design.md)
components/
  ui/                   # primitives: button, card, input, badge, accordion...
  sections/             # hero, features, pricing, faq, footer, navbar
  layout/               # container, section wrapper, stack
data/
  site.ts               # all copy, links, plans, features, FAQs
lib/
  utils.ts              # cn()
```

## 2. The layers (a layer may only use layers below it)

1. **Tokens**: CSS variables in `globals.css`.
2. **Primitives** (`components/ui`): Button, Card, Input, Badge. No page-specific copy.
3. **Layout** (`components/layout`): `Container`, `Section`. All spacing and max-widths come from here.
4. **Sections** (`components/sections`): Hero, Features, Pricing, Faq, Footer. Compose primitives; receive content through props.
5. **Page** (`app/page.tsx`): imports sections and data, nothing else.

## 3. Rules

1. **Tokens only.** No hex values, `bg-blue-400`, `border-black` or `shadow-[4px_4px_0_black]` inside components. Use `bg-main`, `border-border`, `shadow-shadow`.
2. **Define once, use many times.** If a structure appears twice, make it a component. Repeated items render from an array: three plans = one `PricingCard` mapped over `plans`.
3. **Content lives in `data/`.** Headlines, descriptions, link labels and lists are typed objects in `data/site.ts`. Changing text must never mean editing JSX structure.
4. **Variants, not copies.** Use `cva` with a `variant` and `size` prop. Never create `Button2` or `PrimaryButtonLarge`.
5. **Layout primitives for all spacing.** Use `Container` and `Section`; do not fix gaps with one-off margins.
6. **One component per file**, named export, PascalCase file or component name, kebab-case file names under `ui/` to match shadcn.
7. **Props pass-through.** Accept `className` and `...props`, merge with `cn()`.
8. **Flat class lists.** No `!important`. Prefer Tailwind utilities; use CSS only for tokens, base styles and keyframes.

## 4. The `cn()` helper

```ts
// lib/utils.ts
import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}
```

## 5. Server and client components

- Default to **server components**. All hover, focus, active and press effects are CSS, so they need no client code.
- Add `'use client'` only where state, effects or event handlers are required (mobile menu toggle, accordion, dialogs, forms). Keep those components small and leaf-level.
- Do not render values that differ between server and client (dates, random IDs) without handling hydration.

## 6. Next.js specifics

- Fonts: `next/font` in `app/layout.tsx`, applied via a CSS variable. Never a `<link>` tag.
- Images: `next/image` with width and height (or `fill` with a sized parent).
- Links: `next/link`. For a link that looks like a button, use `buttonVariants` (see components.md); never `render={<a />}` on `Button`.
- Metadata: export `metadata` from `layout.tsx` / `page.tsx` (title, description).

## 7. Base UI rules (current library generation)

- `asChild` no longer exists. Compose with the `render` prop: `<DialogTrigger render={<Button variant="neutral" />}>Open</DialogTrigger>`.
- Style state with Base UI data attributes: `data-open`, `data-closed`, `data-checked`, `data-unchecked`, `data-active`, `data-disabled`, `data-highlighted`, `data-popup-open`, `data-panel-open`. Do not use Radix `data-state`.
- Add `isolate` to the app wrapper and make `body` positioned so popups layer correctly: `<body className="relative isolate">`.
- Accordion: no `type="single"` or `collapsible`; `value` and `defaultValue` are arrays; `multiple` allows several open.
- Select: pass an `items` prop (object or `{ value, label }[]`) so `SelectValue` shows labels.
- Drawer: `swipeDirection` replaces `direction`.
- Tooltip provider: `delay` replaces `delayDuration`.
- Removed from the current system: dark mode, `sonner`, `vaul`, `next-themes`. Do not add them.

## 8. Installing components

Prefer the shadcn CLI, per component page on neobrutalism.dev. To set up a themed project:

```
pnpm dlx shadcn@latest init https://neobrutalism.dev/r/styling/blue.json
```

If implementing by hand, follow components.md and keep file paths as `components/ui/<name>.tsx`.

## 9. Workflow

1. Read the request. List the sections the page needs and which items repeat.
2. Write or confirm tokens in `globals.css` (design.md).
3. Create `data/site.ts` with all copy.
4. Build or install primitives, then layout primitives, then sections.
5. Assemble `app/page.tsx` from sections and data.
6. Test at 375, 768 and 1280px; tab through with the keyboard.

## 10. Before you say you're done

- Any JSX block repeated more than once? Extract a component and map over data.
- Any hex value, literal shadow, or `border-black` outside the token layer? Replace with tokens.
- Can the headline, a card's text, and the palette each be changed in one place?
- Every icon-only button has `aria-label`; every input has a label?
- Visible focus on every interactive element? Reduced-motion rule present?
- No dark mode, gradients, soft shadows or white text on `main`?
- Does the page work with no horizontal scroll at 375px?