# components.md: Minimalism components (v0.1)

Read `design.md` and `structure.md` alongside this file.
Every class below uses the tokens from `design.md`. Never substitute hex values or default Tailwind palette colors.
All class recipes are **[recommended]**: the source notes describe behavior but give no class names, so these are this skill's concrete translation.

## Ground rules

1. Native HTML first: `button`, `a`, `input`, `select`, `textarea`, `details/summary`, `table`, `dialog`. Add JavaScript or a library only when the browser cannot do it well (combobox, menus with typeahead, complex focus management).
2. Variants through `cva` and a `variant` prop. Never copy a component to make a variant.
3. Pass `className` and `...props`; merge with `cn()`.
4. Style state with ARIA and native attributes (`aria-selected`, `aria-expanded`, `aria-current`, `aria-invalid`, `disabled`, `open`), not library-specific `data-state`.
5. Every interactive element: visible focus, accessible name, disabled state.
6. Reuse the shared focus string:
   `focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-focus`

---

## 1. Button

Base:
```
inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md border text-sm font-medium
transition-colors duration-120 ease-standard active:translate-y-px
[&_svg]:size-4 [&_svg]:shrink-0 [&_svg]:pointer-events-none
focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-focus
disabled:pointer-events-none disabled:bg-surface-2 disabled:text-fg3 disabled:border-line
```

| Variant | Classes | Use |
|---|---|---|
| `default` | `bg-bg text-fg1 border-line-strong hover:bg-surface-2` | standard action |
| `secondary` | `bg-surface-2 text-fg1 border-line hover:border-line-strong` | quiet filled action |
| `inverted` | `bg-fg1 text-bg border-fg1 hover:bg-fg2 hover:border-fg2` | the one high-emphasis action per view |
| `ghost` | `bg-transparent text-fg1 border-transparent hover:bg-surface-2` | toolbar and low-emphasis actions |
| `destructive` | `bg-danger text-bg border-danger hover:bg-danger/90` | destructive actions only, never decoration |

| Size | Classes |
|---|---|
| `default` | `h-10 px-4` |
| `sm` | `h-8 px-3` |
| `lg` | `h-12 px-6 text-base` |
| `icon` | `size-10` |
| `icon-sm` | `size-8` |

- Icon plus label gap is 8px (`gap-2`). Icon-only buttons require `aria-label`.
- Use `sm` and `icon-sm` only in dense, non-touch UI.
- A button that navigates is a link: use `buttonVariants()` on a `next/link` `Link`, not `<a role="button">`.
- Copy says what happens ("Start free trial", "Save changes"), never "Submit" or "Click here".

## 2. Input, Textarea, Select

```
h-10 w-full rounded-md border border-line-strong bg-bg px-3 text-base text-fg1 placeholder:text-fg3
transition-colors duration-120 ease-standard hover:border-fg2
focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-focus
aria-invalid:border-danger
disabled:bg-surface-2 disabled:text-fg3 disabled:pointer-events-none
```
- `text-base` (16px) on inputs avoids iOS zoom on focus.
- Textarea: same classes, `min-h-24 py-2`, no fixed `h-10`.
- Variants: `default`, `subtle` (`bg-surface-1 border-line`), `ghost` (`border-transparent hover:border-line`). A ghost field still needs a visible edit affordance on hover and focus.
- Password: compact show/hide icon button inside the field, `ghost`, `icon-sm`, `aria-label="Show password"`, `aria-pressed`.
- OTP/PIN: grouped single-character inputs, `size-10` each, optional separator; states default, error (`border-danger`), success, disabled. Compact, not oversized tiles.

## 3. Field (form composition)

```
Field
  Label        text-sm font-medium text-fg1        (8px above the control: mb-2)
  Control
  Description  text-xs text-fg2                    (4px below: mt-1)
  Error        text-xs text-danger                 (4px below: mt-1, role="alert")
```
Fields are 16 to 24px apart (`space-y-4` or `space-y-6`). Link description and error with `aria-describedby`. Keep the error next to its control.

## 4. Checkbox, Radio, Switch, Toggle

- Checkbox/radio: `size-4 border border-line-strong rounded-sm` (radio `rounded-full` is allowed because it is semantically a circle), checked `bg-fg1 border-fg1` with a `text-bg` mark. Native `input` plus `accent-color` or a styled wrapper. States: unchecked, checked, indeterminate, disabled, focus.
- Switch: compact `h-5 w-9` track, small thumb, checked `bg-fg1`. No gloss, no spring.
- Toggle: a button with `aria-pressed`; rest `border-line-strong`, pressed `bg-surface-2 border-fg1`.
- Toggle group (segmented control): joined controls sharing borders (`-ml-px first:ml-0 first:rounded-l-md last:rounded-r-md`), selected `bg-surface-2 border-fg1`.
- Radio group when exactly one choice is allowed. Keep labels and descriptions linked.

## 5. Card

Base: `bg-bg border border-line-subtle rounded-md` (no shadow).
Parts: `Card`, `CardHeader`, `CardBody`, `CardFooter`; padding `p-6` (header, body, footer share it).

| Variant | Change |
|---|---|
| `default` | as above |
| `interactive` | add `transition-colors duration-120 ease-standard hover:border-line-strong` (and make the whole card a link or button) |
| `compact` | `p-4` |
| `flush` | `p-0`, children handle their own spacing |

Cards group content; they do not float. No scale on hover.

## 6. Badge

`inline-flex items-center h-6 rounded-sm border border-line px-2 text-xs font-medium text-fg2`.
Semantic variants change text and border only: `text-success border-success/30`, same for warning, danger, info. Use sparingly; never as decoration.

## 7. Alert

`flex gap-3 rounded-md border border-line p-4`; icon `size-4 mt-0.5` colored only for status; title `text-sm font-medium`; description `text-sm text-fg2`.
Use `role="alert"` for errors, `role="status"` otherwise. Always include text, never color alone.

## 8. Toast

Level 1 surface: `bg-bg border border-line rounded-md shadow-float p-4`. Types success, info, warning, error, loading shown by a small icon plus text. Actions are compact `ghost` buttons. Announce with `role="status"` (or `alert` for errors). Auto-dismiss pauses on hover and focus.

## 9. Tabs

`role="tablist"` with `border-b border-line-subtle`. Trigger:
```
-mb-px border-b-2 border-transparent px-3 h-10 text-sm text-fg2
hover:text-fg1 aria-selected:border-fg1 aria-selected:text-fg1
transition-colors duration-180 ease-standard + focus string
```
Typography and a 2px underline carry the active state. No pill backgrounds. Arrow-key navigation required.

## 10. Accordion / FAQ (native details)

```html
<details class="group border-b border-line-subtle py-4">
  <summary class="flex cursor-pointer list-none items-center justify-between gap-4 text-base font-medium
                  [&::-webkit-details-marker]:hidden"> Question <Plus class="group-open:hidden"/><Minus class="hidden group-open:block"/> </summary>
  <div class="pt-3 text-fg2 max-w-prose">Answer</div>
</details>
```
Swap the icon rather than rotating it. Variants: `borderless`, `compact` (`py-3`), `section`. Do not animate height with bounce; at most a `duration-280` fade.

## 11. Dialog and Sheet (level 2)

Use native `<dialog>` with `showModal()` where possible (needs a small client component).
```
backdrop:bg-black/40 rounded-lg border border-line bg-bg p-6 shadow-modal w-full max-w-md
```
Hierarchy: title (`text-h3`), description (`text-fg2`), content, actions (right-aligned, primary `inverted`). Sheet is the same surface anchored to an edge, `rounded-none`, 280ms slide. Escape closes; focus is trapped and restored.

## 12. Popover, Dropdown menu, Context menu, Command palette (level 1)

Surface: `bg-bg border border-line rounded-md shadow-float p-1 min-w-48`.
Item: `flex h-8 items-center gap-2 rounded-sm px-3 text-sm text-fg1 hover:bg-surface-2` plus a highlighted state (`aria-selected` or the library's highlighted attribute) with the same background; disabled `text-fg3`; shortcuts right-aligned in `Kbd`. Separators `border-t border-line-subtle my-1`.
Command palette adds a bordered search input at the top and muted group labels (`text-xs text-fg3 px-3 py-1`). Keyboard behavior matters more than animation. Use an established accessible primitive for menus and comboboxes.

## 13. Tooltip

`bg-fg1 text-bg text-xs rounded-sm px-2 py-1`, 120ms fade, no artificial delay beyond a short hover intent. Supplementary only; never put essential information in a tooltip.

## 14. Table

`w-full border-collapse text-sm`. Header: `text-left text-xs font-medium text-fg2 border-b border-line py-2 px-3`. Row: `border-b border-line-subtle`, cell `py-3 px-3`. Numeric columns `text-right tabular-nums`. No zebra striping, no heavy borders. Wrap in `overflow-x-auto`.

## 15. Small primitives

- **Avatar:** `size-8` or `size-10`, `rounded-full` allowed, `bg-surface-2 text-fg2 text-xs` fallback initials, no gradients.
- **Kbd:** `inline-flex h-5 min-w-5 items-center justify-center rounded-sm border border-line px-1 text-xs text-fg2`. Never colorful.
- **Separator:** `border-t border-line-subtle` (lighter than major structure).
- **Progress:** `h-1 rounded-sm bg-surface-2` track, `bg-fg1` indicator, no gradient, value text secondary.
- **Slider:** thin track, `size-4` bordered thumb, focus ring, active range `bg-fg1` (or `bg-accent`).
- **Spinner:** `size-4 border-2 border-line border-t-fg1 rounded-full animate-spin`, only for waits over about 400ms.
- **Skeleton:** `bg-surface-2 rounded-md`, static or very subtle pulse, off under reduced motion.
- **Breadcrumb:** ancestors `text-fg2`, current `text-fg1 aria-current="page"`, `/` separators.
- **Pagination:** compact bordered buttons, current page `border-fg1`, no large pills.
- **Calendar/date picker:** neutral surface, hairline border, selected day `bg-fg1 text-bg`, visible focus.
- **File upload:** dashed `border-line-strong rounded-md p-6` drop zone, one line of instruction, one button, then a file list with status. No giant illustrations.
- **Empty state:** centered, optional small icon, title, one-sentence description, one primary action. No illustration.

---

## Landing-page sections

### Navbar
`<header class="border-b border-line-subtle bg-bg">` with `<nav aria-label="Main" class="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 md:px-6">`.
- Left: wordmark as a text link.
- From `md`: 3 to 5 links (`text-sm text-fg2 hover:text-fg1`, current page `text-fg1 underline underline-offset-4` with `aria-current="page"`), then one `inverted` button.
- Below `md`: logo plus an `icon` ghost menu button (`aria-label="Open menu"`, `aria-expanded`). The menu is a full-width panel of stacked links with the call to action at the bottom. Menu toggle is a client component; the rest stays server-rendered.
- Sticky is allowed (`sticky top-0 z-50 bg-bg/95`); no blur.

### Hero (typography-led)
`py-16 md:py-24`, single column, left-aligned, `max-w-3xl`.
- `h1` in `text-h1 md:text-display font-medium`, a benefit not a category.
- One paragraph, `text-base md:text-lg text-fg2 max-w-prose`, at most two sentences.
- One `inverted` button and at most one `default` or `ghost` button.
- Optional visual: a screenshot in a `border border-line-subtle rounded-lg` frame, no shadow. No gradients, blobs or decorative shapes.

### Section wrapper
`py-16 md:py-24`, divided by `border-t border-line-subtle`, not by colored bands. Optional section header: `h2` plus one line of `text-fg2`.

### Feature grid
`grid gap-8 md:grid-cols-2 lg:grid-cols-3`; each item: small `size-5` icon (optional), `h3`, two lines of `text-fg2`. Items are plain text blocks, not cards, unless they need grouping.

### Pricing
Grid of `Card`s from a data array. Plan name (`text-sm font-medium`), price (`text-h1 tabular-nums`) with period in `text-fg2`, 3 to 6 feature lines with a small check icon, one button. The recommended plan uses `border-fg1` and a quiet `Badge`, not a colored fill.

### FAQ
`max-w-3xl` stack of native `details` (see section 10), 5 to 8 items.

### Footer
`border-t border-line-subtle py-12`, link columns in `text-sm text-fg2 hover:text-fg1`, one line of legal text in `text-xs text-fg3`. No competing call to action.

---

## Generic recipe for anything not listed

```
surface : bg-bg text-fg1 border border-line rounded-md
quiet   : bg-surface-1 or bg-surface-2
control : border-line-strong
hover   : subtle tone or border strengthening (transition-colors duration-120 ease-standard)
active  : active:translate-y-px
focus   : focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-focus
disabled: disabled:bg-surface-2 disabled:text-fg3 disabled:pointer-events-none
floating: add shadow-float (popups) or shadow-modal (dialogs); otherwise no shadow
```

Before creating a new component, ask: can native HTML do it? Can an existing primitive do it? Does the pattern repeat? Does the abstraction reduce complexity? If not, don't create it.