# motion.md: Minimalism motion (v0.1)

> **Where this file fits (read first)**
> - `design.md` owns tokens and **UI feedback**: hover, press, focus, small state changes. CSS only.
> - This file owns **page and section motion**: smooth scroll, scroll-linked effects, reveals, parallax, sticky storytelling, active navigation, accordion and overlay transitions.
> - Two duration sets coexist on purpose. UI feedback (design.md): `micro` 120 / `state` 180 / `panel` 280ms. Page motion (section 4 below): `--motion-fast` 180 / `normal` 420 / `slow` 700 / `reveal` 900ms. Never use 420ms or longer on a button, input or other control.
> - If the two disagree about page-level motion, this file wins. About hover, press and focus feedback, `design.md` wins.
> - Code setup (GSAP, ScrollTrigger, Lenis, cleanup, file locations): `structure.md` section 8.
> - Section-by-section effect map: `components.md` ("Section motion map").
> - The tokens in section 4 below must exist in `app/globals.css` and be mirrored in `lib/motion.ts`.
>
> **Close CSS equivalents of the GSAP eases** (so CSS transitions and GSAP match):
>
> | GSAP | CSS |
> |---|---|
> | `power2.out` | `cubic-bezier(0.25, 0.46, 0.45, 0.94)` |
> | `power3.out` | `cubic-bezier(0.215, 0.61, 0.355, 1)` (this is `--ease-standard`) |
> | `power2.inOut` | `cubic-bezier(0.455, 0.03, 0.515, 0.955)` |

## Purpose

Define the motion language for minimalist landing pages.

This is not a generic GSAP animation library. The goal is to make minimalist interfaces feel:
- calm
- editorial
- precise
- spacious
- premium
- readable
- smooth without feeling "animated for the sake of animation"

Motion should support hierarchy and reading, not compete with content.

---

# 1. Core Motion Personality

Minimalism uses **quiet, continuous, typography-led motion**.

Primary characteristics:
- smooth scrolling
- restrained movement
- low transform distances
- opacity/fade transitions
- text highlighting tied to reading progress
- subtle blur-to-sharp reveals
- image reveals through masks/clip-path
- gentle parallax
- staggered content entrances
- reversible scroll-linked states
- smooth same-page navigation
- smooth component state transitions
- almost no dramatic pinning
- almost no aggressive rotation
- almost no bounce

The page should feel like the content is naturally entering and leaving focus as the user reads.

### Golden rule

> If the animation is the first thing the user notices, it is probably too strong for minimalist design.

---

# 2. IMPORTANT: Do Not Treat Scroll Animation As "Play Once"

A common mistake is:

```text
element enters viewport
        ↓
animation plays once
        ↓
animation is finished forever
```

That produces a generic reveal-animation website.

Minimalist motion should usually behave more like:

```text
scroll down
    ↓
element gradually enters its active state

scroll past
    ↓
element gradually leaves its active state

scroll back
    ↓
element becomes active again
```

Whenever an effect is conceptually tied to scroll position, prefer a **continuous ScrollTrigger progress relationship** over a one-time trigger.

Examples:
- opacity changes with scroll progress
- text highlight follows scroll progress
- image clip-path follows progress
- subtle scale follows progress
- blur decreases/increases with progress
- parallax follows scroll
- section color/state follows scroll

Use `scrub` where appropriate.

Do NOT blindly use:

```js
toggleActions: "play none none none"
```

for every section.

That pattern is appropriate only for effects that intentionally behave like a one-time entrance.

---

# 3. Two Animation Categories

Every animation must first be classified.

## A. State / Scroll-Linked Animation

The visual state depends on where the user currently is.

Examples:
- parallax
- text highlighting
- image reveal
- sticky storytelling
- scroll progress
- section transitions
- color transitions

These should normally be reversible.

```text
scroll position
      ↓
animation progress
      ↓
visual state
```

## B. Entrance Animation

The animation communicates that something has just appeared.

Examples:
- initial hero choreography
- first page load
- modal opening
- accordion opening
- menu opening

These may intentionally play once per interaction.

Do not confuse entrance animation with scroll-linked animation.

---

# 4. Default Motion Tokens

```css
--motion-fast: 180ms;
--motion-normal: 420ms;
--motion-slow: 700ms;
--motion-reveal: 900ms;

--motion-distance-sm: 16px;
--motion-distance-md: 32px;
--motion-distance-lg: 56px;

--motion-stagger-sm: 0.04;
--motion-stagger-md: 0.08;
--motion-stagger-lg: 0.12;
```

Preferred easing:

```js
ease: "power2.out"
ease: "power3.out"
ease: "power2.inOut"
```

For scroll-linked animations:

```js
scrub: 0.5
scrub: 0.8
scrub: 1
```

For UI state transitions, prefer short transitions rather than long timelines.

---

# 5. Smooth Scroll Is a Global System

Smooth scrolling is not just an effect attached to one section.

The entire page should share one coherent scroll system.

Preferred behavior:
- smooth but responsive
- no excessive inertia
- no scroll hijacking
- preserve native accessibility
- disable/reduce effects on reduced-motion preferences
- keep anchor navigation synchronized with the smooth-scroll engine
- avoid nested competing scroll systems

If using Lenis or another smooth-scroll layer, synchronize it correctly with GSAP ScrollTrigger.

The scroll system must remain functional when:
- navigating through navbar anchors
- clicking a CTA to another section
- opening/closing overlays
- resizing the viewport
- using keyboard navigation

---

# 6. Same-Page Navigation Must Be Smooth

Navbar links such as:

```text
Home
Features
About
Pricing
Contact
```

should not jump directly to the target.

Use smooth scrolling to the section.

Conceptually:

```text
click #features
      ↓
calculate target position
      ↓
smooth scroll
      ↓
ScrollTrigger updates
      ↓
target section enters its correct visual state
```

Do not implement this as a simple instant:

```js
element.scrollIntoView()
```

unless reduced motion is requested.

When using a smooth-scroll library, use its scroll-to API so the library and ScrollTrigger remain synchronized.

---

# 7. Anchor Navigation With Fixed / Sticky Navbar

Account for navbar height.

Bad:

```text
target heading
████████
↑ hidden behind navbar
```

Good:

```text
navbar
────────────

target section
████████████
```

Prefer:

```css
scroll-margin-top: var(--navbar-height);
```

or calculate an equivalent offset in the scroll-to function.

The active section should not end up underneath the fixed navbar.

---

# 8. Active Navigation State

When scrolling through sections, the navbar may update the active link.

Use:
- subtle opacity
- foreground color
- underline
- small indicator
- border change

Avoid aggressive animation.

The active state should be reversible:

```text
Features active
    ↓
Pricing active
    ↓
Contact active
```

Do not permanently add classes as the user scrolls.

Use IntersectionObserver or ScrollTrigger state/progress to derive the current section.

---

# 9. Signature Effect: Scroll Text Highlight

This should be one of the primary minimalist effects.

### Visual idea

A paragraph starts muted.

As the user scrolls:
- the current words/lines become darker
- previously read content remains readable
- the highlight progresses naturally with scroll
- scrolling upward reverses the highlight
- scrolling downward advances it

Example:

```text
The product helps teams
████████████████
understand complex data
```

Implementation approaches:
1. word-level spans
2. line-level spans
3. background highlight moving across text
4. color interpolation
5. opacity/foreground-color interpolation

Preferred approach:

```text
muted text → active text
```

rather than:

```text
invisible → visible
```

The reader should always be able to read the full paragraph.

---

# 10. Fade-Up Reveal

Default section entrance.

```text
opacity: 0 → 1
y: 24px → 0
```

Recommended:
- distance: 16–40px
- duration: 0.6–0.9s
- stagger: 0.05–0.12s

For a scroll-driven version, make the effect reversible:

```js
gsap.fromTo(element,
  { opacity: 0.25, y: 24 },
  {
    opacity: 1,
    y: 0,
    scrollTrigger: {
      trigger: element,
      start: "top 90%",
      end: "top 55%",
      scrub: 0.6
    }
  }
);
```

Use a one-time entrance only when there is a deliberate reason.

---

# 11. Fade + Blur Reveal

A premium minimalist effect.

Initial:

```css
opacity: 0;
filter: blur(8px);
transform: translateY(20px);
```

Final:

```css
opacity: 1;
filter: blur(0);
transform: translateY(0);
```

For scroll-linked use, blur should increase again when the element leaves its active range.

Use sparingly.

Best for:
- hero copy
- large editorial statements
- section introductions
- selected headlines

Do not apply blur to huge numbers of elements simultaneously.

---

# 12. Text Line Reveal

For large headings:

```text
line 1
line 2
line 3
```

Each line moves upward from an overflow-hidden wrapper.

Pattern:

```text
wrapper
  └── line
```

Animation:

```text
yPercent: 100 → 0
```

For initial hero choreography, this can play once.

For scroll-driven editorial sections, tie progress to ScrollTrigger so it can reverse when scrolling upward.

Preferred for:
- hero headings
- major section titles
- editorial statements

Avoid letter-by-letter animation by default.

---

# 13. Image Mask Reveal

Images should often reveal through a clean mask.

Patterns:
- bottom → top
- left → right
- center expansion
- clip-path inset reveal

Example:

```js
gsap.fromTo(image,
  { clipPath: "inset(0 100% 0 0)" },
  {
    clipPath: "inset(0 0% 0 0)",
    scrollTrigger: {
      trigger: image,
      start: "top 90%",
      end: "top 50%",
      scrub: 0.7
    }
  }
);
```

Scrolling back should reverse the reveal.

The image itself can simultaneously scale subtly:

```text
scale: 1.05 → 1
```

Avoid large zooms.

---

# 14. Minimal Parallax

Use subtle depth.

Recommended movement:
- foreground image: 0.1–0.25 speed difference
- background: 0.05–0.15
- decorative element: 0.15–0.3

The movement should be discovered rather than announced.

Good:

```text
image moves 20px while section moves 100px
```

Bad:

```text
image flies across the screen
```

Parallax is inherently reversible because it is tied to scroll position.

---

# 15. Staggered Content

Use stagger for repeated elements.

Example:

```js
// Plays once on mount. For sections users revisit, drive it with ScrollTrigger (see section 10).
gsap.from(items, {
  opacity: 0,
  y: 24,
  stagger: 0.08,
  duration: 0.7,
  ease: "power2.out"
});
```

For repeated sections that users may revisit, consider a scroll-progress version rather than a permanent one-time reveal.

The stagger should feel like a sequence, not a cascade.

---

# 16. Scroll-Linked Typography

Typography can subtly respond to scroll.

Possible effects:
- opacity
- color
- blur
- letter spacing
- scale
- x/y movement
- underline/highlight progress

Recommended priority:

```text
color
opacity
small translation
small scale
blur
```

Do not start with rotation or 3D transforms.

---

# 17. Smooth Panel Reveal

For major visual transitions:

```text
section A
   ↓
image slowly appears
   ↓
section B becomes dominant
```

Use opacity, transform and/or clip-path.

When the transition represents scroll position, make it reversible.

Good for:
- hero → story transition
- product → features
- case study sections
- editorial storytelling

Avoid hard full-screen snapping unless the design explicitly calls for it.

---

# 18. Sticky Content — Use Sparingly

Minimalism can use sticky positioning, but it should feel like reading structure rather than spectacle.

Example:

```text
LEFT
sticky heading

RIGHT
paragraph
paragraph
paragraph
paragraph
```

The heading stays while content changes.

Use this for:
- product explanation
- process sections
- feature storytelling

The sticky state should naturally enter and leave as the user scrolls.

---

# 19. Hero Choreography

Recommended sequence:

1. navigation fades in
2. eyebrow appears
3. heading line reveal
4. description fades in
5. CTA appears
6. hero image reveals
7. subtle image parallax begins

Example timeline:

```text
0.00  navbar
0.15  eyebrow
0.25  heading
0.50  description
0.65  CTA
0.80  visual
```

Hero load choreography can intentionally play once.

After the hero:
**prefer reversible scroll-linked behavior**.

---

# 20. Accordion / Disclosure Motion

Component interactions must feel like part of the same motion system.

Do not use:

```css
display: none → display: block
```

with an abrupt content appearance.

Avoid animating:

```css
height: auto
```

directly.

Preferred pattern:

```text
closed
height: 0
opacity: 0

open
height: measured content height
opacity: 1
```

Animate the wrapper height using GSAP or a CSS grid technique.

Example conceptual sequence:

```text
button click
    ↓
icon rotates subtly
    ↓
content height expands
    ↓
content opacity increases
    ↓
content settles
```

Recommended:
- 250–450ms
- `power2.out` or `power3.out`
- subtle icon rotation
- no bounce

When closing, reverse the same timeline.

The interaction should work repeatedly:

```text
open
 ↓
close
 ↓
open
 ↓
close
```

---

# 21. Modal / Drawer / Popover Motion

Opening:

```text
opacity: 0 → 1
scale: 0.98 → 1
```

or:

```text
opacity: 0 → 1
y: 8px → 0
```

Closing should reverse it.

Never rely on only:

```text
display: none
```

for the visual transition.

Respect:
- focus management
- Escape
- keyboard navigation
- reduced motion

---

# 22. Buttons and Micro Interactions

Minimalist buttons should use CSS transitions whenever possible.

Good:
- subtle background change
- border change
- 1–2px translation
- opacity
- underline movement

Avoid launching a GSAP timeline for every hover.

Use GSAP only when interaction has meaningful choreography.

---

# 23. Scroll-To + Animation Synchronization

This is critical.

When the user clicks:

```text
Navbar → Features
```

the destination section should not only scroll smoothly.

Its animation state should also be correct.

Sequence:

```text
click
 ↓
smooth scroll starts
 ↓
ScrollTrigger progress updates
 ↓
section animations progress naturally
 ↓
target settles into active state
```

Do not manually fire the target section's animation separately.

Let scroll position remain the source of truth.

---

# 24. Refresh / Resize Behavior

Scroll-driven animation must survive:
- viewport resize
- font loading
- responsive layout changes
- orientation changes
- dynamic content changes

Use:

```js
invalidateOnRefresh: true
```

when dimensions are calculated dynamically.

Call the appropriate ScrollTrigger refresh after layout-affecting content changes.

Never hard-code viewport-dependent measurements if they can be calculated.

---

# 25. React / GSAP Rules

Use scoped GSAP contexts and clean them up when components unmount.

Prefer:

```js
const ctx = gsap.context(() => {
  // animations
}, container);

return () => ctx.revert();
```

Use:

```js
gsap.matchMedia()
```

for responsive setups.

Do not leave global ScrollTriggers running after component unmount.

---

# 26. Reduced Motion

Respect:

```css
@media (prefers-reduced-motion: reduce)
```

Disable or simplify:
- parallax
- scrubbed transforms
- large movement
- blur animation
- complex timelines
- smooth-scroll hijacking

Keep:
- instant opacity/state changes
- readable transitions
- functional interaction
- accessible anchor navigation

If reduced motion is enabled, anchor navigation may jump directly or use a very short transition.

---

# 27. Animation Lifecycle Rules

Before implementing any animation, ask:

### Is this:
1. page-load choreography?
2. scroll-position state?
3. hover state?
4. click state?
5. navigation?
6. component open/close?

Then choose the mechanism.

```text
page-load      → GSAP timeline
scroll state   → ScrollTrigger + scrub
hover          → CSS transition
click state    → reversible timeline
anchor nav     → smooth scroll
accordion      → reversible height/opacity timeline
modal          → reversible enter/exit timeline
```

Do not use ScrollTrigger for ordinary button interactions.

---

# 28. Effects To Prefer

Priority:

1. ScrollTextHighlight
2. ReversibleFadeReveal
3. BlurReveal
4. LineReveal
5. ImageMaskReveal
6. StaggerReveal
7. SubtleParallax
8. StickyStory
9. ScrollColorTransition
10. GentleZoom
11. SmoothAnchorNavigation
12. AccordionReveal
13. ModalReveal

---

# 29. Effects To Avoid By Default

Avoid:
- aggressive 3D rotation
- bouncing cards
- giant overshoots
- constant skew
- rapid scaling
- excessive cursor effects
- excessive horizontal scrolling
- dozens of simultaneous triggers
- animation on every tiny UI element
- one-time reveal on every section
- abrupt anchor jumps
- unanimated accordion/modal state changes

Minimalism requires restraint and continuity.

---

# 30. Responsive Rules

Desktop may use:
- text highlight
- sticky storytelling
- subtle parallax
- line reveals
- larger image masks

Mobile should simplify.

Prefer:
- shorter distances
- less parallax
- fewer pinned sections
- simpler text reveals
- no unnecessary horizontal scroll
- reduced animation density

Use GSAP matchMedia for breakpoint-specific animation setups.

---

# 31. Minimalism Landing Page Recipe

### Hero
`LineReveal + FadeReveal + ImageReveal`

### Intro
`TextHighlight`

### Features
`StaggerReveal`

### Product visual
`ImageMaskReveal + subtle Parallax`

### Story
`StickyStory`

### Testimonial
`FadeReveal + TextHighlight`

### Final CTA
`FadeReveal + gentle scale`

### Navbar
`SmoothAnchorNavigation + ActiveSection`

### FAQ
`AccordionReveal`

---

# 32. Design Test

The animation is correct when:

- the user notices the content first
- the motion makes the page feel expensive
- scrolling feels continuous
- typography remains readable
- there is visual rhythm without spectacle
- scrolling upward feels as intentional as scrolling downward
- clicking navigation never produces a jarring jump
- opening and closing UI components feels connected to the page's motion language
- removing one animation would sometimes make the page better

Final principle:

> Minimalism should feel like the page is calmly revealing itself — and calmly un-revealing itself as the user moves back.