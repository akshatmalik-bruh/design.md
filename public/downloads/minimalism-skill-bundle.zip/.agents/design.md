# design.md: Minimalism (v0.1)

Read `components.md` and `structure.md` alongside this file.
This file defines how things LOOK and MOVE. Use it for every UI you build in this style.

Lineage: the philosophy follows Monoset (quiet, monotone, 4px grid, hairlines, three motion durations) and modest-ui (semantic tokens, native controls).
Tags: **[notes]** = rule carried over from the source notes (Monoset / modest-ui), not independently checked. **[recommended]** = concrete value or rule added by this skill.

---

## 1. The look in one sentence

Quiet, monotone and typography-led: a neutral ramp, 1px hairlines instead of shadows, a strict 4px spacing grid, conservative corners, and motion that confirms an action and gets out of the way.

## 2. Principles (in priority order)

1. **Hierarchy first.** Build it from size, weight, line height, spacing, position, then border and tone. Reach for color last.
2. **Monotone first.** Neutral palette. Semantic colors (success, warning, danger, info) appear only when they carry meaning.
3. **Hairlines beat shadows.** Surfaces are flat and separated by 1px borders. Shadows are only for things that genuinely float.
4. **Everything snaps to 4px.**
5. **Motion confirms, then gets out of the way.** Three durations, one easing curve, no bounce.
6. **Remove before adding.** Every element must improve hierarchy, usability, state or accessibility. If not, delete it.

Minimalism is not: everything white, no hierarchy, no borders, tiny type, or empty screens. Personality comes from the typeface, the type scale, the spacing rhythm, the grid and the copy.

## 3. Tokens [recommended values]

The source notes name the token concepts but give no values (and modest-ui's own baseline is black-on-white with 0 radius). These values are this skill's defaults. Put them in `app/globals.css` (Tailwind v4). Never hard-code them in components.

```css
:root {
  /* color: neutral ramp */
  --bg: #ffffff;
  --surface-1: #fafafa;
  --surface-2: #f5f5f5;
  --fg1: #0a0a0a;          /* primary text */
  --fg2: #525252;          /* secondary text */
  --fg3: #737373;          /* tertiary text, placeholders (about 4.7:1 on white) */
  --border-subtle: #e5e5e5; /* structure: dividers, cards, tables */
  --border-default: #d4d4d4;
  --border-strong: #8a8a8a; /* control boundaries: inputs, buttons (about 3.4:1) */
  --focus: #0a0a0a;
  --accent: #0a0a0a;        /* monotone by default */
  --accent-foreground: #ffffff;
  --success: #15803d;
  --warning: #a16207;
  --danger: #b91c1c;
  --info: #1d4ed8;          /* all four pass 4.5:1 on white (calculated) */

  /* shape */
  --radius-sm: 2px;
  --radius-md: 4px;
  --radius-lg: 8px;

  /* elevation: level 0 is "no shadow" */
  --shadow-float: 0 4px 12px rgb(0 0 0 / 0.08);   /* level 1: popover, dropdown, toast */
  --shadow-modal: 0 12px 32px rgb(0 0 0 / 0.16);  /* level 2: dialog, sheet */
}

/* Optional dark theme: swap tokens only, never touch components */
[data-theme="dark"] {
  --bg: #0a0a0a; --surface-1: #141414; --surface-2: #1c1c1c;
  --fg1: #fafafa; --fg2: #a3a3a3; --fg3: #8a8a8a;
  --border-subtle: #262626; --border-default: #333333; --border-strong: #6b6b6b;
  --focus: #fafafa; --accent: #fafafa; --accent-foreground: #0a0a0a;
  --success: #4ade80; --warning: #facc15; --danger: #f87171; --info: #60a5fa;
}

@theme inline {
  --color-bg: var(--bg);
  --color-surface-1: var(--surface-1);
  --color-surface-2: var(--surface-2);
  --color-fg1: var(--fg1);
  --color-fg2: var(--fg2);
  --color-fg3: var(--fg3);
  --color-line-subtle: var(--border-subtle);
  --color-line: var(--border-default);
  --color-line-strong: var(--border-strong);
  --color-focus: var(--focus);
  --color-accent: var(--accent);
  --color-accent-foreground: var(--accent-foreground);
  --color-success: var(--success);
  --color-warning: var(--warning);
  --color-danger: var(--danger);
  --color-info: var(--info);

  --radius-sm: 2px; --radius-md: 4px; --radius-lg: 8px;
  --shadow-float: 0 4px 12px rgb(0 0 0 / 0.08);
  --shadow-modal: 0 12px 32px rgb(0 0 0 / 0.16);
  --ease-standard: cubic-bezier(0.2, 0, 0, 1);

  --text-h3: 1.25rem;    --text-h3--line-height: 1.75rem;
  --text-h2: 1.75rem;    --text-h2--line-height: 2.25rem;
  --text-h1: 2.5rem;     --text-h1--line-height: 3rem;
  --text-display: 3.5rem; --text-display--line-height: 3.75rem;
  --text-display--letter-spacing: -0.02em;
  --text-h1--letter-spacing: -0.02em;
}
```

| Role | Classes |
|---|---|
| page background / surfaces | `bg-bg`, `bg-surface-1`, `bg-surface-2` |
| text | `text-fg1`, `text-fg2`, `text-fg3` |
| borders | `border-line-subtle` (structure), `border-line`, `border-line-strong` (controls) |
| focus | `outline-focus` |
| semantic | `text-danger`, `bg-danger`, `border-danger` (same for success, warning, info) |
| shape | `rounded-sm`, `rounded-md`, `rounded-lg` |
| elevation | `shadow-float`, `shadow-modal` |

Rules: components consume semantic tokens only (`bg-bg`, `text-fg1`, `border-line`), never hex values, `bg-gray-100` or `border-neutral-200`. Do not require every token if the product does not need it; the token set itself should stay small.

## 4. Typography [scale is recommended; line heights follow the 4px grid]

| Level | Size / line height | Use |
|---|---|---|
| display | 56 / 60 | one hero headline per page (`text-display`, with `text-h1` below `md`) |
| h1 | 40 / 48 | page title |
| h2 | 28 / 36 | section title |
| h3 | 20 / 28 | subsection, card title |
| body | 16 / 24 (`text-base`) | paragraphs, inputs |
| body-sm | 14 / 20 (`text-sm`) | secondary text, buttons, nav |
| caption | 12 / 16 (`text-xs`) | badges, helper text, table headers |

- One typeface (two at most: one text, one mono). Load with `next/font`. Do not force a specific family on the project.
- Weights: 400 for body, 500 for labels and headings, 600 only for emphasis. Never make every heading extra bold.
- Tight tracking (`-0.02em`) only on h1 and display.
- Body line length 45 to 80 characters: use `max-w-prose` or `max-w-[65ch]`-style constraints on text blocks.
- Use `tabular-nums` for numbers in tables and prices.
- Do not use oversized hero type, ALL CAPS labels everywhere, or decorative fonts.

## 5. Spacing: 4px grid [notes + recommended classes]

Tailwind's spacing unit is 4px, so integer utilities already fit: `1, 2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24` (4 to 96px).
Do not use fractional utilities (`p-2.5`, `gap-1.5`) or arbitrary values (`mt-[13px]`).

| Relationship | Spacing |
|---|---|
| heading to paragraph | 16 or 24 (`mb-4`, `mb-6`) |
| paragraph to paragraph | 16 |
| label to control | 8 |
| control to description or error | 4 |
| field to field | 16 or 24 |
| item to item inside a section | 24 |
| section to section (inside a page) | `py-16 md:py-24` (64 / 96) |

Use `gap` on flex and grid, not margins on children.

## 6. Borders and shape

- Default border is **1px**. Structure (cards, tables, dividers, nav, sections) uses `border-line-subtle` or `border-line`.
- **Control boundaries** (input, select, checkbox, outlined button) use `border-line-strong` so they meet the 3:1 contrast needed to see the control. [recommended]
- Emphasis or selected state: `border-fg1`.
- Radius is conservative: `rounded-md` default, `rounded-sm` for badges and small controls, `rounded-lg` for dialogs. `rounded-none` is a valid editorial variant. Never `rounded-full` on cards or buttons, never 24px+ radii.

## 7. Elevation: three levels only

| Level | Use | Treatment |
|---|---|---|
| 0 flat (default) | cards, sections, inputs, buttons | no shadow, 1px border |
| 1 floating | popover, dropdown, tooltip, toast, command palette | `shadow-float` + 1px border |
| 2 modal | dialog, sheet | `shadow-modal` + 1px border |

No glow, colored shadow, large soft elevation, or extra levels.

## 8. Motion [durations from notes; easing value recommended]

| Token | Duration | Use |
|---|---|---|
| fast | 120ms | hover, press, focus, tooltip |
| normal | 180ms | state transitions, menus, tabs |
| slow | 280ms | larger reveals, panels, dialogs |

- Classes: `transition-colors duration-120 ease-standard`, `duration-180`, `duration-280`. No other durations.
- One easing curve, `ease-standard` (`cubic-bezier(0.2, 0, 0, 1)`). The Monoset notes say to use the source's exact curve when known; replace this value if you confirm it.
- Animate `color`, `background-color`, `border-color`, `opacity`, and `transform` (1px nudges only). Do not animate layout properties for micro-interactions.
- Allowed: tone change, border change, underline, opacity, tiny translate.
- Never: spring, bounce, elastic overshoot, rotation, scale-on-hover, glow, 800ms+ transitions, constant floating or looping motion.
- Spinners only for waits over about 400ms [notes]; never flash a spinner for short operations. Skeletons are static neutral blocks, shimmer optional and subtle.
- Reduced motion, in `globals.css`:
  ```css
  @media (prefers-reduced-motion: reduce) {
    *, *::before, *::after {
      animation-duration: 0.01ms !important;
      animation-iteration-count: 1 !important;
      transition-duration: 0.01ms !important;
      scroll-behavior: auto !important;
    }
  }
  ```

## 9. States

- **Rest:** quiet and flat.
- **Hover:** a slight strengthening of tone, border or text color (or an underline for links). Wrap in `@media (hover: hover)` or use Tailwind's `hover:` (v4 already applies it only on hover-capable devices).
- **Active / pressed:** a tiny cue, `active:translate-y-px` or a stronger surface. [notes]
- **Focus:** always visible, `focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-focus`. Never remove outlines globally. No glow or thick colored rings.
- **Disabled:** lower contrast and no pointer events, but keep text readable: `disabled:bg-surface-2 disabled:text-fg3 disabled:border-line disabled:pointer-events-none`. Do not just drop opacity to 50%.
- **Invalid:** `aria-invalid` styling with `border-danger`, plus a text message. Never color alone.
- **Selected / current:** `aria-selected`, `aria-current`, `aria-expanded`, `aria-pressed`, `aria-checked` drive styling, so it works with any component library.

## 10. Responsive

- Mobile first. Build at 375px, then enhance at `sm` 640, `md` 768, `lg` 1024, `xl` 1280.
- Do not just shrink: reduce horizontal padding (`px-4 md:px-6 lg:px-8`), drop columns (1 to 2 to 3), stack actions, keep line length readable, and keep the type hierarchy (`text-h1 md:text-display`).
- Touch targets at least 40px high on touch layouts; use the default button size, not `sm`.
- Content width: `max-w-6xl` containers; text blocks `max-w-prose`.
- Wide tables scroll inside `overflow-x-auto`; the page never scrolls sideways.
- Test at 375, 768 and 1280px.

## 11. Density

Offer comfortable (default) and compact only where the product is data-dense (tables, forms, admin). Express it through component `size` or `compact` props, not a global theme. Both modes keep the same visual language.

## 12. Accessibility floor

Semantic HTML, keyboard operable, visible focus, accessible names (`aria-label` on icon-only buttons, `aria-hidden="true"` on decorative icons), labels linked to inputs, errors announced, 4.5:1 text contrast, 3:1 control boundaries, reduced-motion support.

## 13. Anti-patterns

Do not use: huge rounded cards (`rounded-3xl`), glassmorphism, gradients (`bg-gradient-*`), glowing buttons, colored shadows, `shadow-2xl`, `hover:scale-105`, pills and badges everywhere, floating everything, bounce or spring motion, arbitrary spacing, a dozen colors, low-contrast gray text, decorative borders everywhere, oversized icons, an illustration in every empty state.
The goal is not "generic modern SaaS with less color". It is fewer decisions, made precisely.

## 14. Final test

For every visual element ask: does it improve hierarchy, usability, state or accessibility? If not, remove it.